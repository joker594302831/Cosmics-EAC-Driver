# Kernel-Driver-Undetected-EAC-Only
Here is a driver source thats undetected on EAC right now. 
Here is a driver source i won't be updating, its FUD on eac as off now.I wont help any skids use this, its just needs a brain
